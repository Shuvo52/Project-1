
$('#navigation').slimmenu(
	{
		resizeWidth: '768',
		collapserTitle: '',
		animSpeed: 'medium',
		easingEffect: null,
		indentChildren: false,
		childrenIndenter: '&nbsp;'
	});
	
	$('#navigation').onePageNav();
	
	
	
	
	$('.slider').show().bxSlider({
	pager:false,
	auto:true,
	speed:1000,


	});

    
    $('.post_slider').bxSlider({
	pager:false,
	auto:false,
	speed:2500,
	slideWidth: 340,
    minSlides: 1,
    maxSlides: 3,
	 moveSlides: 2,
    slideMargin: 20
	});
	
	
		$(document).ready(function() {
		var s = $("#sticker");
		var pos = s.position();                   
		$(window).scroll(function() {
			var windowpos = $(window).scrollTop();
			if (windowpos >= pos.top) {
				s.addClass("stick");
			} else {
				s.removeClass("stick");
			}
		});
	});
	
	
	
	
	
	
	
	
	$(function() {
	  $('a[href*=#]:not([href=#])').click(function() {
		if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
		  var target = $(this.hash);
		  target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
		  if (target.length) {
			$('html,body').animate({
			  scrollTop: target.offset().top
			}, 3000);
			return false;
		  }
		}
	  });
	});
